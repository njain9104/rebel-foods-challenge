import BeerContainer from "./BeerContainer";

export { BeerContainer };
