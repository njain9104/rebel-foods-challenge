import "./App.css";
import { BeerContainer } from "./BeerContainer";

function App() {
  return (
    <div className="App">
      <header>REBEL FOODS BEERCRAFT</header>
      <BeerContainer />
    </div>
  );
}

export default App;
